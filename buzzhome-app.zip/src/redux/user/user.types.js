var keyMirror = require('key-mirror');

const UserTypes = keyMirror({
    UPDATE_ROLE: null,
    
})

export default UserTypes