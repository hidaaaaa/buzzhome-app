{
    "numResults": 26,
        "results": [
            {
                "id": "fb-post-item",
                "postedTimestamp": 1596807065,
                "savedTimestamp": 1596807403746,
                "author": {
                    "text": "Moon Eric",
                    "link": "https://www.facebook.com/profile.php?id=100016750118710&fref=gs&__tn__=%2CdC-R-R&eid=ARBYzzekIrAOxE8SMlJy1l4FHqus7JFkeqLoFbmMiYuCQuC7VnrjRzPLfh7duUhg19GsMZ1GlrmEieXG&hc_ref=ARTMqMu3qymYLJgkr8bWhg578MDKznMHkGR9n5ddjXC1F7MVn7u6WkZzG9_XxbrEc-c&dti=950713841719944&hc_location=group"
                },
                "location": {},
                "tagged": {},
                "content": "Leasing the apartment near the airport The Botanica 104 phổ quang tân bình district! 53m2 1 bed 1 wc! High floor and ventilated balcony! Full good furniture! Free gym and pool! 13m/ month! Contact: Moon 0938498120",
                "postedTimeString": "Friday, August 7, 2020 at 1:31 PM",
                "link": "https://www.facebook.com/groups/950713841719944/permalink/2142631409194842/",
                "photos": [
                    "https://www.facebook.com/photo.php?fbid=746065002628497&set=pcb.2142631409194842&type=3&ifg=1&__tn__=HH-R&eid=ARBDMESO5pHZTLMFVS2-CC49JLjbPlbBNTSM8u7p_bC2cQObgXrbv5zWxDQuQn7AVJk-bDN1caHWgBZu",
                    "https://www.facebook.com/photo.php?fbid=746065022628495&set=pcb.2142631409194842&type=3&ifg=1&__tn__=HH-R&eid=ARA-sAAD3B6klA4EWOqBgchLjohDj0lhwnFC_kXxZiwtsUrKvY-e1jOeg6dYKoRc_12aKg41mbL8rKbl",
                    "https://www.facebook.com/photo.php?fbid=746065065961824&set=pcb.2142631409194842&type=3&ifg=1&__tn__=HH-R&eid=ARA5SHTKdZsw_cZvJBMbX2V8XvNhxkQNiD4wiIVhkaSrcmFyUFG7_hcM5fNzFwy9EDqRvpOBwAgW_CPW",
                    "https://www.facebook.com/photo.php?fbid=746065055961825&set=pcb.2142631409194842&type=3&ifg=1&__tn__=HH-R&eid=ARAZSmWLcXmc6_G5COYawRF2LKFuRqhrqVpANOkGDy0WUZR613_cRdYUL-EvC3dBgNgvlYvoHfloqzO2",
                    "https://www.facebook.com/photo.php?fbid=746065105961820&set=pcb.2142631409194842&type=3&ifg=1&__tn__=HH-R&eid=ARBLQSPQeAnfuyjCsE7qUk_5Uqlx4cP6VFC_J6kuvRlW2FM4NkCSkcQviEyuRqqTfkEN6gJIqYA36J-I"
                ],
                "price": 560.5717141549964
            },
            {
                "id": "fb-post-item",
                "postedTimestamp": 1596786676,
                "savedTimestamp": 1596787248523,
                "author": {
                    "text": "Nhà Trọ SG",
                    "link": "https://www.facebook.com/NhaTroSG?fref=gs&__tn__=%2CdC-R-R&eid=ARC7YqFLFgl6D6u8N1MSfclP3Utr_qeTy92T0KB5szuIjY4po9YNTc9ZJXRBiEhWzf9U4GQw9bd1oq7e&hc_ref=ARS3PEeF8T6DGKzrWGyFYPFobG_YSxY9FESuwhi_3JAOvb-oN_5ROmrvkMfgQYzIies&dti=950713841719944&hc_location=group"
                },
                "location": {},
                "tagged": {},
                "content": "#Agent\nChào các anh, chị Host\n- B&P HOUSE cần nguồn số lượng lớn căn hộ dịch vụ giá từ 4 đến 7tr q1,q3,q4,q5,q10,gv,pn,bt...\n- hoa hồng 6th- nửa tháng, 1 năm-1 tháng\n-Các anh chị host cần ký gửi ib em hoặc lh sđt/zalo: 0777881105 Bình  \nSaigon Expat - Airbnb - Homestay - Apartment\nfxy\nSee Translation",
                "postedTimeString": "Friday, August 7, 2020 at 7:51 AM",
                "link": "https://www.facebook.com/groups/950713841719944/permalink/2142012145923435/",
                "photos": [],
                "price": 301.8463076219211
            },
            {
                "id": "fb-post-item",
                "postedTimestamp": 1596785824,
                "savedTimestamp": 1596786348541,
                "author": {
                    "text": "Pham Thanh Thuy",
                    "link": "https://www.facebook.com/kitty.meomeo.9404?fref=gs&__tn__=%2CdlC-R-R&eid=ARDog8cMmIT24yU59AxulaRXi1-THHTmueAcP_FsxMWDL3JFvwAt6qb9m0zTkDCGyfgL9xbeisA7_Sjc&hc_ref=ARQ7MRhx8RUzGK7vrIWLGupSPwsyHZo50_LJVLoFj2Dkk3yP2YPIiqsAISZtzDbTVaM&ref=nf_target&dti=950713841719944&hc_location=group"
                },
                "location": {},
                "tagged": {},
                "content": "🔥🔥🔥🔥 PROMOTION 🔥🔥🔥🔥\n💜🔔Stylish studio in a highly desirable location in the heart of D1🔔💜\n🏘Located : Bui Thi Xuan Street,D1\n💥Close to Ben Thanh market & 2 mins go to Tao Dan Park\n💥Here you will find countless restaurants, cafés ,convenient shop and further entertainment venues.\n💵 Monthly Rental : 🔥Now : 360 usd/month (It was 400 USD)\n💢Include: tap water,internet,TV cable,cleaning 2 times/week\n❌Excluding: electricity 4000/kWh\n💰Deposit: Only 1 month\n😊Please inbox me for more information and book appointment to check it out",
                "postedTimeString": "Friday, August 7, 2020 at 7:37 AM",
                "link": "https://www.facebook.com/groups/950713841719944/permalink/2141968019261181/",
                "photos": [
                    "https://www.facebook.com/photo.php?fbid=137378294713551&set=pcb.137378451380202&type=3&ifg=1&__tn__=HH-R&eid=ARDnAACrJbsKxVTqVFklqn_3rI0CypQ2vY_Ij_0qR-WsUTJEWEkOmn7nNWhGizRiAPbGTGWOnQRT0mn0",
                    "https://www.facebook.com/photo.php?fbid=137378304713550&set=pcb.137378451380202&type=3&ifg=1&__tn__=HH-R&eid=ARDaOMMyR33G92sp2U2hH9xTd13onYcOBI705qeK6ITX8F6zSlX58HarbL6yn43YMbDZRkNfHIPslPlT",
                    "https://www.facebook.com/photo.php?fbid=137378334713547&set=pcb.137378451380202&type=3&ifg=1&__tn__=HH-R&eid=ARA7P77VcQXPw6bF1LelTCVFJCehlioy0fCntndm5mfWpEdMBN5Ut_zSbC0yHJQ-Fe0SioAQnwy4dAAp",
                    "https://www.facebook.com/photo.php?fbid=137378348046879&set=pcb.137378451380202&type=3&ifg=1&__tn__=HH-R&eid=ARBHZsCauSaRbCHG8y8LPrPD73_L2ImuV88YBJ-qJyJhuKkKysEl7I3GS7aYe8DHdMzi5Lkobv1SSBWg",
                    "https://www.facebook.com/photo.php?fbid=137378374713543&set=pcb.137378451380202&type=3&ifg=1&__tn__=HH-R&eid=ARAdaGqQ44m6HFVs9jKeF6JB6x_EBQ18TRsW_fZPVkHltTRRFFZDD_wF-j7yLwBH8Qm9jpJOUtNHauIm"
                ],
                "price": 360.0
            },
            {
                "id": "fb-post-item",
                "postedTimestamp": 1596775354,
                "savedTimestamp": 1596775553459,
                "author": {
                    "text": "Moon Eric",
                    "link": "https://www.facebook.com/profile.php?id=100016750118710&fref=gs&__tn__=%2CdC-R-R&eid=ARCCFOIm_R4XyxTdxc3ScjGbInN8zNjn2G3766CYvsYefM8000jPyPyJXKr7J2RnV14LB1z7Mys8Xy2A&hc_ref=ARQoYMVKtCzeyiQx8ETmrT5ZQ1i3P-xkakO7Sp8wY7rSx-x-HY4l9EhQSYUnV0tzdqY&dti=950713841719944&hc_location=group"
                },
                "location": {},
                "tagged": {},
                "content": "Leasing the apartment near the airport The Botanica 104 phổ quang tân bình district! 53m2 1 bed 1 wc! High floor and ventilated balcony! Full good furniture! Free gym and pool! 13m/ month! Contact: Moon 0938498120",
                "postedTimeString": "Friday, August 7, 2020 at 4:42 AM",
                "link": "https://www.facebook.com/groups/950713841719944/permalink/2141701675954482/",
                "photos": [
                    "https://www.facebook.com/photo.php?fbid=745806062654391&set=pcb.2141701675954482&type=3&ifg=1&__tn__=HH-R&eid=ARDsNS45Ap4RE3RUcPz6TTGLOz8Hi0U5RsFGy9mEPpTctOJuDCJhu0F-2lu8q8UxPvQy64Ze0CV8mHGp",
                    "https://www.facebook.com/photo.php?fbid=745806082654389&set=pcb.2141701675954482&type=3&ifg=1&__tn__=HH-R&eid=ARDu7Li7AY4oShXVf1PrzJmhghgtHhv18mFlaJ7PaTWeHcNxU7VljMKen9CFRJ8FX1mO9P13yagG4rKP",
                    "https://www.facebook.com/photo.php?fbid=745806109321053&set=pcb.2141701675954482&type=3&ifg=1&__tn__=HH-R&eid=ARA0Ql_pCIXA0qpz3DMqakG0ZLOF1LmInaxqFPjjPTR9fpBRxmeSH-a07OinAsDXiQuyaBmn03VmSGHc",
                    "https://www.facebook.com/photo.php?fbid=745806145987716&set=pcb.2141701675954482&type=3&ifg=1&__tn__=HH-R&eid=ARDzzjob2nxDIeyZkoWyyonsKV3IjVB8837IuPmOWMbc-8r-FCFaKL02XIYrKuOCZlbwk6e8E__NBUwz",
                    "https://www.facebook.com/photo.php?fbid=745806162654381&set=pcb.2141701675954482&type=3&ifg=1&__tn__=HH-R&eid=ARCPgEwW-WFxr8hoU_Bh6PQ8WvdKJm1G5QbePwmcCVSVOR51QLlhkbY7i2I-iEsYr1BDZk4Lz1I6ixZp"
                ],
                "price": 560.5717141549964
            },
            {
                "id": "fb-post-item",
                "postedTimestamp": 1596774775,
                "savedTimestamp": 1596775025824,
                "author": {
                    "text": "An Thi Thuy Dung",
                    "link": "https://www.facebook.com/ana3636?fref=gs&__tn__=%2CdC-R-R&eid=ARAWzUIkw4SUMpgB1ahtvatg5CCIb-ZRGGEHhGYpUME5cFPPKfb4zEFPuDQR8knln4J-jvZyOP9LdBmS&hc_ref=ARQC-Ra3cKMMEY72wr_zZOLttX3rgre9tVFdB1_tM5Pum0v37e20tsGwZsWE6yvC5tc&dti=950713841719944&hc_location=group"
                },
                "location": {},
                "tagged": {},
                "content": "💥FULL EQUIPMENT APARTMENT 2 BEDROOMS on THE 34th FLOOR with SUPER NICE VIEW FOR RENT in VINHOME CENTRAL PARK, BINH THANH district\n☘️RENTAL PRICE: 800$ (approximately 18.540.000 vnd) per month. ☘️\n🌼 High-class living space with outstanding facilities: 14ha riverside park, swimming pool FOR FREE, gym FOR FREE, restaurant, 24/24 security system, shool, hospital, shopping mall,...\n🌼 Vinhome Central Park is a place with ideal space and living environment in Viet Nam.\n🌹🌹A new modern apartment in Vinhome Central Park (on the 34th floor of the Park 7 Tower) , Dien Bien Phu street, District Binh Thanh. It only takes 10 minutes to reach District 1. There are plenty of shops and eateries located on the premise of the building complex. It is a very secure apartment complex with lots of security. Its located in a peaceful quiet neighborhood surrounded by parks. Ideal for everyone looking for a great value for money for their stay in Ho Chi Minh City. The apartment has high-speed internet over 36 Mbps.\nThe space amenities:\n----------\n- Equipment: Smart TV, fridge, air-cons, hair-dryer, electric cooker, microwave, washing machine, dinner table, work table, cabinets.\nFully automatic smart toilet system.\nOther common features include:\n- Swimming pools FOR FREE\n- gym FOR FREE\n- Amazing 14ha riverside park with a huge green place and BBQ area\n- Many kinds of shops, restaurants, mini stop, circle K, bank, supermarket(Vinmart) on the ground floor\n- Around 10 mins to District 1, one way only without the hassle of having traffic jams.\n- 5 mins to Phuc An Khang Hospital, AIS (Australia international school),5 mins to Mega Market, 20 mins to TSN airport\n- Good location with lots of green park surrounding the property.\n- Safety with security 24/7\nIf you are interested please send me a PM.",
                "postedTimeString": "Friday, August 7, 2020 at 4:32 AM",
                "link": "https://www.facebook.com/groups/950713841719944/permalink/2141695765955073/",
                "photos": [
                    "https://www.facebook.com/photo.php?fbid=10213894144827815&set=pcb.2141695765955073&type=3&ifg=1&__tn__=HH-R&eid=ARBeEP7IezWikVTAFRkfW28lb0LiTyXEaVqLcOJf6LWaP64LASNGRmqpylxzf33io0LuvBFCPbtFzcPo",
                    "https://www.facebook.com/photo.php?fbid=10213894145187824&set=pcb.2141695765955073&type=3&ifg=1&__tn__=HH-R&eid=ARCTFMxERM_J5wi-q7VL5ZWjPdigjst0LdMbYGTxbVv2LA1ME0G47884aAm6TLSSr68Aj32G0g2loUWy",
                    "https://www.facebook.com/photo.php?fbid=10213894145467831&set=pcb.2141695765955073&type=3&ifg=1&__tn__=HH-R&eid=ARD7CUKcKEO4B5n9LiNQKccNQrXAno8RZkCU1UikFh0h6kxVKQ3ruHXI9LkiOKxFNG-QTx0YnnqLIRlT",
                    "https://www.facebook.com/photo.php?fbid=10213894145707837&set=pcb.2141695765955073&type=3&ifg=1&__tn__=HH-R&eid=ARA3q4qiQAXV30AnUL3_cy_JbDIMr5R_tifBAO1s1iPbAis_sUbCHg2GEwqSDDRLZkbGE1mBytPdia_w",
                    "https://www.facebook.com/photo.php?fbid=10213894146267851&set=pcb.2141695765955073&type=3&ifg=1&__tn__=HH-R&eid=ARBGmOUt5OG-k6RY70to9WozRrP-02YBsY5dTH4oiYuyaifRkqQremdkllKU3OB-_BQXeSaPsGZqP0EI"
                ],
                "price": 800.0,
                "districtLocation": "1"
            },
            {
                "id": "fb-post-item",
                "postedTimestamp": 1596767066,
                "savedTimestamp": 1596767808260,
                "author": {
                    "text": "Nguyễn Trang",
                    "link": "https://www.facebook.com/profile.php?id=100048733681550&fref=gs&__tn__=%2CdC-R-R&eid=ARAjvNmXojl0kBlRxHBUlkaVD0K7d7joisfaAYK2ifmZA-dSKVkN-QKMdBoF6ty53dmbUvD2eCIUpzL3&hc_ref=ARRzbcSX-aBah5LOj8ar4cxJy91vWv8GP8agct889e92tB_qx0CT54t7N6DvjG0t5KI&post_id=2141457515978898&dti=950713841719944&hc_location=group"
                },
                "location": {},
                "tagged": {},
                "content": "<3 PARAGON APARTMENT IN CENTRE OF BINH THANH – BIG DISCOUNT JUST FROM 430 $ (10 MIL) FOR STUDIO <3\nAddress: 178/33B Nguyen Van Thuong Street, Ward 25, Binh Thanh District\n👉 Conveniently located: Conveniently located, easy to go through District 1, 2 3, Phu Nhuan, Go Vap. It only takes 5 minutes to go to Sai Gon Bridge and VINHOMES center Park (VIEW LANDMARK 81)\n👉 There are many famous shopping, Supermarket, food service, GYM, and entertainment areas\n👉 Apartment is furnished with high-class furnishings, full of household appliances, some apartment have balcony, window nice view.\n👉 ESPECIALLY FREE SERVICE\n✅ Laudry service (2 times/week)\n✅ Changing sheet (1 times/week)\n✅ Cleaning room ( 2 times/week)\n✅ FREE Internet\n✅ Security 24/24\n✅FREE Water\n✅ FREE Parking\n👉 Price: DISCOUNT JUST FROM FROM 430 $ (10 MIL) FOR STUDIO\n☎️ For more information, please contact me: 0903 92 02 05 – Ms Thu (zalo/whatsapp)",
                "postedTimeString": "Friday, August 7, 2020 at 2:24 AM",
                "photos": [
                    "https://www.facebook.com/photo.php?fbid=172316791069443&set=pcb.2141457515978898&type=3&ifg=1&__tn__=HH-R&eid=ARAYTydt_kkB5sHtR6a1HFw-YMtobbA0xUk4doDdy7P346HizuZpLC4Y60HEUWVKSoFspjHoTrJTRgvG",
                    "https://www.facebook.com/photo.php?fbid=172316681069454&set=pcb.2141457515978898&type=3&ifg=1&__tn__=HH-R&eid=ARAITFkb7kmVf6Wo7hnsUb-8o9jRPgP-U-azPtOfPGaB4QqY6UJUHVWqOmsaMkz5KCdXaGm8uC7qB42m",
                    "https://www.facebook.com/photo.php?fbid=172316831069439&set=pcb.2141457515978898&type=3&ifg=1&__tn__=HH-R&eid=ARAvYGyHWOWKHg5ka5AZ_RugioqpYZi4YLkaV99--PBqPqUQnGdjyQq8jHRSoFsK4r_EQ2uGMBcPMMyQ"
                ],
                "price": 430.0,
                "districtLocation": "1"
            },
            {
                "id": "fb-post-item",
                "postedTimestamp": 1596765104,
                "savedTimestamp": 1596765664742,
                "author": {
                    "text": "Moon Eric",
                    "link": "https://www.facebook.com/profile.php?id=100016750118710&fref=gs&__tn__=%2CdC-R-R&eid=ARAGoLvDnVu3QfkyySkY-wAH0qXXkdhTxSUzoTRVqBHoxvGt3bgMjJNVACcGtVRPyvmCUMe4--ZYWexQ&hc_ref=ARRfZFiGrXPSwqco2gIpBd5laWJkgrzNBlXKgyuLrUchyHH6AN5MzYDqZMbHZq-Yz2c&dti=950713841719944&hc_location=group"
                },
                "location": {},
                "tagged": {},
                "content": "Leasing the apartment near the airport The Botanica! 53m2 1 bed 1 wc! High floor and ventilated balcony! New full furniture and free gym and pool! 13m/ month! Contact: Moon 0938498120",
                "postedTimeString": "Friday, August 7, 2020 at 1:51 AM",
                "link": "https://www.facebook.com/groups/950713841719944/permalink/2141406665983983/",
                "photos": [
                    "https://www.facebook.com/photo.php?fbid=745717902663207&set=pcb.2141406665983983&type=3&ifg=1&__tn__=HH-R&eid=ARAm3RcW6Jq8opAaMQ3WXRq2t3Mqef4b_-pSbOVkGVTWnCLz99l14sOtOK67ras5nSFFcHZRsgQeuib7",
                    "https://www.facebook.com/photo.php?fbid=745717919329872&set=pcb.2141406665983983&type=3&ifg=1&__tn__=HH-R&eid=ARBWC4on2uqemkM0d-0MDGbzqyMMzIyGhgmWqfvP13U6yPtmMKvEVgJI7F6KVnG_Qp9FnA0JJFK_0D-v",
                    "https://www.facebook.com/photo.php?fbid=745717949329869&set=pcb.2141406665983983&type=3&ifg=1&__tn__=HH-R&eid=ARA3R8vKcbdtbihnXiPVS_A6oY0TbqJG2B_Fj2zniWDWTmEc1lqyswiTpXL7GiEOyF3XCwBfBJZXT6oO",
                    "https://www.facebook.com/photo.php?fbid=745717995996531&set=pcb.2141406665983983&type=3&ifg=1&__tn__=HH-R&eid=ARCaaMxixW6wGQPNPs_zPp3gZBKnjBlrwSaxaAR4jm1qwRV3x36oSXZrYBiKgvElweXqjwLeHjOEeGts",
                    "https://www.facebook.com/photo.php?fbid=745718015996529&set=pcb.2141406665983983&type=3&ifg=1&__tn__=HH-R&eid=ARDiz6ZhBcYmSrxmF45CBMG3Itrlpxnul2aIkc6tU0lx4VyAy2TKniY2OfpkJg-JJ8ITp4DeXTqgPfHs"
                ],
                "price": 560.5717141549964
            },
            {
                "id": "fb-post-item",
                "postedTimestamp": 1596707785,
                "savedTimestamp": 1596762060565,
                "author": {
                    "text": "Gia Bảo",
                    "link": "https://www.facebook.com/profile.php?id=100021548979132&fref=gs&__tn__=%2CdlC-R-R&eid=ARBsK-ptMyfky1m6mZ5h_2XdcGCwaJy0EAFTWjePAan6b90bVFr4TaDWZV4vDhEYS0VyaHLl0zKj7kHq&hc_ref=ARQao_qVHEhuhH2kSJ8FITm9tBbLKcSgsUOEhwpx8QPsziHcS-iwhzAWJF_JsUhPiJM&ref=nf_target&dti=950713841719944&hc_location=group"
                },
                "location": {},
                "tagged": {},
                "content": "#Domushome\nMình cho thuê: Phòng Trọ Cao Cấp, Căn Hộ Mini Quận 7\nGiá từ 3tr7 trở lên\nĐúng giá đúng phòng có nhu cầu thuê thật sự hiện liên hệ: 0344184022 Bảo\nSee Translation",
                "postedTimeString": "Thursday, August 6, 2020 at 5:56 AM",
                "link": "https://www.facebook.com/groups/950713841719944/permalink/2139572589500724/",
                "photos": [
                    "https://www.facebook.com/photo.php?fbid=679202782808015&set=pcb.963588217386473&type=3&ifg=1&__tn__=HH-R&eid=ARCJ91w3iMKGVXJfEqjFJZTeH9F1gukj_-Gaiv5BSi2N_NpvenHHDXOnUzP23omPYBF0eXgZO2r799J-",
                    "https://www.facebook.com/photo.php?fbid=679202806141346&set=pcb.963588217386473&type=3&ifg=1&__tn__=HH-R&eid=ARDbpdx9oiCBf4KeDhWLErRsT-kfwsQ8lVs0ojI208Pc-pJXZlZ1rbK7DMYfD4w7SqMWUyaTtGk7iI8P",
                    "https://www.facebook.com/photo.php?fbid=679202849474675&set=pcb.963588217386473&type=3&ifg=1&__tn__=HH-R&eid=ARAML1wcHddmce-suRJ1JVB8MLA3sDSrjJQX_P38daMMwSxCby3gbCb1ld8QMNrIwum8K4yF5XBOWnbT",
                    "https://www.facebook.com/photo.php?fbid=679202832808010&set=pcb.963588217386473&type=3&ifg=1&__tn__=HH-R&eid=ARAhPUoXEsUUyZDmKYCxOHya4sQC8rY21blTFT_mtdV3wHKImCwg01-JMueHc-tYmZNzTmCtSzmINQzU"
                ],
                "price": 129.3627032665376,
                "districtLocation": "7"
            },
            {
                "id": "fb-post-item",
                "postedTimestamp": 1596701774,
                "savedTimestamp": 1596762060858,
                "author": {
                    "text": "Tiên Tiên",
                    "link": "https://www.facebook.com/chau.helen.31?fref=gs&__tn__=%2CdlC-R-R&eid=ARCoW2wwmpyLSO_onxIj3fZTI0LSHlnAxliOvlA7wgEf45jl-uG0NxJEuXfvlY2Rh6HQVRGyAVDP30fg&hc_ref=ART_71Es2KdxVNwuIRvALeiy1KYDrWlUtliz0DJnlhp8tPdAFqKqUYvYbjbUyyYc-AY&ref=nf_target&dti=950713841719944&hc_location=group"
                },
                "location": {},
                "tagged": {},
                "content": "Serviced apartment for rent on Vo Thi Sau, District 3\n410 $ · Ho Chi Minh City\nRenting a new serviced apartment, everything in the house has not been used , 35m2 room with airy balcony.\nRental: 9.5 million VND / month\nDistrict 3 center area near the market easy to move.\nFree cleaning 2 times a week\nElectricity 4.000k / kwh\nWater 100k / person\nWashing clothes each time 50k\nCho Thuê căn hộ dịch vụ đường Vo Thi Sau Quận 3\n410 $ · Thành phố Hồ Chí Minh\nCho thuê căn hộ dịch vụ mới xây , mọi thứ trong nhà đều chưa qua sửa dụng phòng 35m2 có ban công thoáng mát.\nGiá thuê : 9.5tr/tháng\nKhu quận 3 khu trung tâm gần chợ dễ di chuyển.\nMiễn phí dọn dẹp 1 tuần 2 lần\nĐiện 4k/kwh\nNước 100k/người\nGiờ giấc tự do\nGiặt quần áo mỗi lần 50k\n😊😊😊",
                "postedTimeString": "Thursday, August 6, 2020 at 4:16 AM",
                "link": "https://www.facebook.com/groups/950713841719944/permalink/2139388626185787/",
                "photos": [
                    "https://www.facebook.com/photo.php?fbid=1234832566867444&set=pcb.1234833403534027&type=3&ifg=1&__tn__=HH-R&eid=ARCHvxCN0Y_OLYdCJJKKa0Ajzvg59eAn7X2qzTO6Vjm4QafRTdsR8hZfOVlDMkHqlOCZglzWrzCtucwj",
                    "https://www.facebook.com/photo.php?fbid=1234832603534107&set=pcb.1234833403534027&type=3&ifg=1&__tn__=HH-R&eid=ARAgYqUFe817Kb_mt-RTcGg_x088dyj8a_1_t1Nd4thO8rxhqWl86eqdNuirvgzdzX7dfojn07oYTYAo",
                    "https://www.facebook.com/photo.php?fbid=1234832653534102&set=pcb.1234833403534027&type=3&ifg=1&__tn__=HH-R&eid=ARBj5LOipHo8DqHW_1BPj36jTHJWLEPR9lbcSUpVB3S0v8BIzaANGYsuKcvbb4KhzAB5KVQbKIuwF50j",
                    "https://www.facebook.com/photo.php?fbid=1234832723534095&set=pcb.1234833403534027&type=3&ifg=1&__tn__=HH-R&eid=ARCz7sS7Gkk5qREdW3zJDRmJO9ptxqJjKmtSZS3-DEg5VkWaTxQUquW_MSLez7MDMxw6-bI0Qb-cIrGn",
                    "https://www.facebook.com/photo.php?fbid=1234832763534091&set=pcb.1234833403534027&type=3&ifg=1&__tn__=HH-R&eid=ARCzhGvCKEU6q7SMja1tI9Ta7sUEE9oZe3qP5eYhEDcUsoLso6Urlm5z36yCcl6x8P5IoCbkql5iw2ub"
                ],
                "price": 410.0
            }
        ]
}